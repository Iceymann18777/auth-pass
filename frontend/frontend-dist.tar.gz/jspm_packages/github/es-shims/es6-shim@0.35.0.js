define(["github:es-shims/es6-shim@0.35.0/es6-shim"], function(main) {
  return main;
});