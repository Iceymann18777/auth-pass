/* */ 
var createRange = require('./_createRange');
var range = createRange();
module.exports = range;
