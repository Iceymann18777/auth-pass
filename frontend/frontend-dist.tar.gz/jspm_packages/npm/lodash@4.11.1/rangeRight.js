/* */ 
var createRange = require('./_createRange');
var rangeRight = createRange(true);
module.exports = rangeRight;
