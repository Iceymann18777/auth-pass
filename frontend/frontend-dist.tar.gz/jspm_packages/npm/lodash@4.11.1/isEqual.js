/* */ 
var baseIsEqual = require('./_baseIsEqual');
function isEqual(value, other) {
  return baseIsEqual(value, other);
}
module.exports = isEqual;
