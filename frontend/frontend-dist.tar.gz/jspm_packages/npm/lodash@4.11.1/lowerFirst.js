/* */ 
var createCaseFirst = require('./_createCaseFirst');
var lowerFirst = createCaseFirst('toLowerCase');
module.exports = lowerFirst;
