define(["npm:moment@2.13.0/moment.js"], function(main) {
  return main;
});