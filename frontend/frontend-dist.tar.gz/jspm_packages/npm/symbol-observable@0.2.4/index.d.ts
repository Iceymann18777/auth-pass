declare const observableSymbol: symbol;
export = observableSymbol;