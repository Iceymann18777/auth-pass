/* */ 
module.exports = require('./forEach');
